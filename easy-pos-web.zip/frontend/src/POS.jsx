import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';

export default function POS() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [cart, setCart] = useState([]);
  const barcodeRef = useRef();

  useEffect(() => {
    if (!query) { setResults([]); return; }
    const t = setTimeout(() => {
      axios.get(`/api/products?q=${encodeURIComponent(query)}`).then(r => setResults(r.data));
    }, 200);
    return () => clearTimeout(t);
  }, [query]);

  function addProduct(prod) {
    setCart(prev => {
      const idx = prev.findIndex(p => p.product_id === prod.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx].qty += 1;
        copy[idx].subtotal = copy[idx].qty * copy[idx].price;
        return copy;
      }
      return [...prev, { product_id: prod.id, name: prod.name, price: prod.price, qty: 1, subtotal: prod.price }];
    });
  }

  function removeItem(index) { setCart(c => c.filter((_,i)=>i!==index)); }
  function changeQty(i, val) {
    setCart(c => { const copy = [...c]; copy[i].qty = Math.max(1, Number(val)); copy[i].subtotal = copy[i].qty * copy[i].price; return copy; });
  }
  function total() { return cart.reduce((s,it)=>s+it.subtotal,0); }

  function onSubmitSale() {
    const payload = { items: cart.map(it=>({product_id: it.product_id, qty: it.qty, price: it.price})), paid: total(), user_id:1 };
    axios.post('/api/sales', payload).then(r=>{
      alert('تم تسجيل البيع. فاتورة: '+r.data.invoice_no);
      window.open(`/api/sales/${r.data.saleId}/print`,'_blank');
      setCart([]);
    }).catch(e=>alert('خطأ: '+e));
  }

  return (
    <div className="pos-container" dir="rtl">
      <div className="left-panel">
        <input ref={barcodeRef} placeholder="ابحث باسم الصنف أو باركود" value={query} onChange={e=>setQuery(e.target.value)} />
        <div className="results">
          {results.map(r => <div key={r.id} className="result" onClick={()=>addProduct(r)}>{r.name} - {r.price} ج</div>)}
        </div>
      </div>
      <div className="right-panel">
        <h2>عربة المشتريات</h2>
        {cart.map((it,idx)=>
          <div key={idx} className="cart-item">
            <span>{it.name}</span>
            <input type="number" value={it.qty} onChange={e=>changeQty(idx,e.target.value)} />
            <span>{it.subtotal} ج</span>
            <button onClick={()=>removeItem(idx)}>حذف</button>
          </div>
        )}
        <div>الإجمالي: {total()} ج</div>
        <button onClick={onSubmitSale} disabled={cart.length===0}>إتمام البيع</button>
      </div>
    </div>
  );
}