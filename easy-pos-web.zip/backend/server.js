const express = require('express');
const bodyParser = require('body-parser');
const Database = require('better-sqlite3');
const cors = require('cors');
const PDFDocument = require('pdfkit');
const fs = require('fs');
const shortid = require('shortid');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

const dbFile = path.join(__dirname, 'pos.db');
const db = new Database(dbFile);

if (!fs.existsSync(dbFile) || db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='products'").all().length === 0) {
  const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  db.exec(schema);
  console.log('Database initialized.');
}

function generateInvoiceNo() {
  return 'INV-' + shortid.generate().toUpperCase();
}

app.get('/api/products', (req, res) => {
  const q = req.query.q || '';
  const rows = db.prepare("SELECT * FROM products WHERE name LIKE ? OR sku LIKE ? OR barcode LIKE ? LIMIT 200")
                 .all(`%${q}%`, `%${q}%`, `%${q}%`);
  res.json(rows);
});

app.get('/api/products/:id', (req, res) => {
  const row = db.prepare("SELECT * FROM products WHERE id = ?").get(req.params.id);
  res.json(row || {});
});

app.post('/api/products', (req, res) => {
  const p = req.body;
  const stmt = db.prepare("INSERT INTO products (sku,name,price,cost,stock,category_id,barcode) VALUES (?,?,?,?,?,?,?)");
  const info = stmt.run(p.sku, p.name, p.price, p.cost || 0, p.stock || 0, p.category_id || null, p.barcode || null);
  res.json({id: info.lastInsertRowid});
});

app.post('/api/sales', (req, res) => {
  const sale = req.body;
  const invoice_no = generateInvoiceNo();
  const total = sale.items.reduce((s,it) => s + (it.price * it.qty) - (it.discount||0), 0);
  const change_amount = (sale.paid||0) - total;

  const insertSale = db.prepare("INSERT INTO sales (invoice_no,total,paid,change_amount,customer_id,user_id) VALUES (?,?,?,?,?,?)");
  const info = insertSale.run(invoice_no, total, sale.paid || 0, change_amount, sale.customer_id || null, sale.user_id || null);
  const saleId = info.lastInsertRowid;

  const insertItem = db.prepare("INSERT INTO sale_items (sale_id,product_id,qty,price,discount,subtotal) VALUES (?,?,?,?,?,?)");
  const updateStock = db.prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
  const getProduct = db.prepare("SELECT * FROM products WHERE id = ?");

  const txn = db.transaction((items) => {
    for (const it of items) {
      const subtotal = (it.price * it.qty) - (it.discount || 0);
      insertItem.run(saleId, it.product_id, it.qty, it.price, it.discount || 0, subtotal);
      const prod = getProduct.get(it.product_id);
      if (prod) {
        updateStock.run(it.qty, it.product_id);
      }
    }
  });

  txn(sale.items);

  res.json({saleId, invoice_no, total, change_amount});
});

app.get('/api/sales/:id/print', (req,res) => {
  const sale = db.prepare("SELECT * FROM sales WHERE id = ?").get(req.params.id);
  if (!sale) return res.status(404).send('Sale not found');
  const items = db.prepare("SELECT si.*, p.name FROM sale_items si LEFT JOIN products p ON p.id = si.product_id WHERE si.sale_id = ?").all(req.params.id);

  const doc = new PDFDocument({size: 'A4', margin: 30});
  res.setHeader('Content-Type','application/pdf');
  doc.pipe(res);

  doc.fontSize(16).text('فاتورة بيع', {align:'center'});
  doc.moveDown();
  doc.fontSize(12).text(`رقم الفاتورة: ${sale.invoice_no}`);
  doc.text(`التاريخ: ${sale.created_at}`);
  doc.moveDown();

  items.forEach(it => {
    doc.text(`${it.name} x${it.qty}  —  ${it.price}  =  ${it.subtotal}`);
  });

  doc.moveDown();
  doc.text(`المجموع: ${sale.total}`);
  doc.text(`المدفوع: ${sale.paid}`);
  doc.text(`الباقي/صرف: ${sale.change_amount}`);

  doc.end();
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log('Server running on', PORT));